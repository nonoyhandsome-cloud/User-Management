const userTable = document.querySelector('#userTable tbody');
const form = document.getElementById('userForm');
const errorEl = document.getElementById('formError');

function loadUsers() {
  fetch('/users')
    .then(res => res.json())
    .then(users => {
      userTable.innerHTML = '';
      users.forEach(user => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${user.name}</td>
          <td>${user.email}</td>
          <td>${user.mobile}</td>
          <td>
            <button onclick='editUser(${JSON.stringify(user)})'>Edit</button>
            <button onclick='deleteUser("${user.id}")'>Delete</button>
          </td>
        `;
        userTable.appendChild(tr);
      });
    });
}

form.onsubmit = (e) => {
  e.preventDefault();
  const name = form.name.value.trim();
  const email = form.email.value.trim();
  const mobile = form.mobile.value.trim();
  const id = form.userId.value;

  // Validation
  if (!email.includes('@')) return showError("Invalid email");
  if (!mobile.startsWith('09')) return showError("Mobile number must start with 09");

  const userData = { name, email, mobile };
  const method = id ? 'PUT' : 'POST';
  const url = id ? `/users/${id}` : '/users';

  fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData)
  })
    .then(res => {
      if (!res.ok) return res.json().then(err => Promise.reject(err.error));
      return res.json();
    })
    .then(() => {
      form.reset();
      errorEl.textContent = '';
      loadUsers();
    })
    .catch(showError);
};

function deleteUser(id) {
  fetch(`/users/${id}`, { method: 'DELETE' })
    .then(() => loadUsers());
}

function editUser(user) {
  form.name.value = user.name;
  form.email.value = user.email;
  form.mobile.value = user.mobile;
  form.userId.value = user.id;
}

function showError(msg) {
  errorEl.textContent = msg;
}

loadUsers();