const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

const DATA_FILE = path.join(__dirname, 'users.json');

app.use(express.json());
app.use(express.static(__dirname)); // serve index.html and script.js

// Ensure users.json exists
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, '[]', 'utf8');
}

const readUsers = () => JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const writeUsers = (data) => fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');

// Create user
app.post('/users', (req, res) => {
  const users = readUsers();
  const newUser = { id: Date.now().toString(), ...req.body };
  users.push(newUser);
  writeUsers(users);
  res.status(201).json(newUser);
});

// Read all users
app.get('/users', (req, res) => {
  const users = readUsers();
  res.json(users);
});

// Read specific user
app.get('/users/:id', (req, res) => {
  const user = readUsers().find(u => u.id === req.params.id);
  user ? res.json(user) : res.status(404).json({ error: 'User not found' });
});

// Update user
app.put('/users/:id', (req, res) => {
  const users = readUsers();
  const index = users.findIndex(u => u.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'User not found' });
  users[index] = { ...users[index], ...req.body };
  writeUsers(users);
  res.json(users[index]);
});

// Delete user
app.delete('/users/:id', (req, res) => {
  let users = readUsers();
  const index = users.findIndex(u => u.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'User not found' });
  const deletedUser = users.splice(index, 1);
  writeUsers(users);
  res.json(deletedUser[0]);
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));